import { default as React, useEffect, useRef } from "react";

import styled from "styled-components";
// Components
import FullButton from "../Buttons/FullButton";
// Assets

import ImageSlider from "../../components/Elements/ImageSlider";
import images from "../../data/images";
import { useDispatch, useSelector } from "react-redux";
import { fetchManufacturers, fetchModels, fetchYears } from "../../redux/features/dataSlice";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Header() {
  const childRef = useRef(null);
  const history = useNavigate();
  const years = useSelector((state) => state.years);
  const models = useSelector((state) => state.models);
  const manufacturers = useSelector((state) => state.manufacturers);
  const status = useSelector((state) => state.status);
  const dispatch = useDispatch();
  const [manufacturer, setManufacturer] = useState("");
  const [model, setModel] = useState("");
  const [year, setYear] = useState("");

  useEffect(() => {
    dispatch(fetchYears());
    dispatch(fetchModels(manufacturer));
    dispatch(fetchManufacturers());
  }, [dispatch]);


  const handleSlideNext = (slideNext) => {
    // Now, you have a reference to the child function
    childRef.current = slideNext;

  };


  const handleSlidePrev = (slidePrev) => {
    // Now, you have a reference to the child function
    childRef.current = slidePrev;

  };

  const handleSlideNextClick = () => {
    // Call the child function when the button is clicked
    if (childRef.current) {
      childRef.current();
    }
  };


  const handleSlidePrevClick = () => {
    // Call the child function when the button is clicked
    if (childRef.current) {
      childRef.current();
    }
  };

  // if (status === 'loading') {
  //   return <p>Loading...</p>;
  // }

  // if (status === 'failed') {
  //   return <p>Error loading data</p>;
  // }

  const handleManufacturerChange = (value) => {
    setManufacturer(value);
    dispatch(fetchModels(value));
  }

  return (
    <>
      <Wrapper id="home" className="container flexSpaceCenter">
        <LeftSide className="flexCenter">
          <div dir="rtl">
            <h1 className="extraBold font60">قيم سيارتك</h1>
            <h1 className="extraBold font60">بتسعيرة السوق</h1>
            <h2 >واحجز خدمة تسعير المركبات الان</h2>


            <BtnWrapper>
              <FullButton title="ابدأ خدمة التقييم الآن" />
            </BtnWrapper>


            <NextPrevWrapper>
              <button
                style={{ backgroundColor: "white", width: "30px", height: "30px", borderRadius: "50px", borderColor: "#a5a6a8", borderWidth: "1px", margin: "5px" }}

                onClick={(e) => {
                  e.preventDefault();
                  handleSlidePrevClick();
                }}
              >
                {"<"}
              </button>
              <button
                style={{ backgroundColor: "white", width: "30px", height: "30px", borderRadius: "50px", borderColor: "#a5a6a8", borderWidth: "1px", margin: "5px" }}

                onClick={(e) => {
                  e.preventDefault();
                  handleSlideNextClick();
                }}
              >
                {">"}
              </button>
            </NextPrevWrapper>



          </div>
        </LeftSide>
        <RightSide>
          <ImageWrapper>
            {/* <Img className="radius8" src={HeaderImage} alt="office" style={{zIndex: 9}} /> */}

            <ImageSlider onSlideNext={handleSlideNext} onSlidePrev={handleSlidePrev}>
              {images.map((image, index) => {
                return (
                  <div className="image-container" key={index} style={{ width: "250px", position: "relative", backgroundColor: "rgba(38, 170, 225, 0.05)", float: "right" }}>
                    <img src={image.imgURL} alt={image.imgAlt} style={{ width: "500px", float: "right" }} />
                  </div>
                );
                // return <img key={index} src={image.imgURL} alt={image.imgAlt} />;
              })}
            </ImageSlider>



          </ImageWrapper>
        </RightSide>
      </Wrapper>

      <HeaderElement1 className="d-flex justify-content-center align-items-center" style={{ zInndex: "2", left: "50px", top: "200px", margin: "auto" }}>
        <div class="row  " style={{ margin: "0 auto", width: "80%" }}>
          <div class="col-lg-3">
            <select id="typeText" value={manufacturer} placeholder="Type here" class="form-control" onChange={(e) => handleManufacturerChange(e.target.value)}>
              {
                manufacturers?.manufacturers?.map((manufacturer, index) => {
                  return (
                    <option key={index} value={manufacturer?.id}>{manufacturer?.name}</option>
                  )
                })
              }
            </select>
          </div>
          <div class="col-lg-3">
            <select id="typeText" placeholder="Type here" class="form-control" onChange={(e) => setModel(e.target.value)}>
              {
                models?.models?.map((model, index) => {
                  return (
                    <option key={index} value={model?.id}>{model?.name}</option>
                  )
                })
              }
            </select>
          </div>
          <div class="col-lg-3">
            <select id="typeText" placeholder="Type here" class="form-control" onChange={(e) => setYear(e.target.value)}>
              {
                years?.years?.map((year, index) => {
                  return (
                    <option key={index} value={year?.id}>{year?.name}</option>
                  )
                })
              }
            </select>
          </div>

          <div class="col-lg-3">
            <EavaluateButton href="" onClick={() => history(`/checkout?&${manufacturer}&${model}&${year}`)}>Evaluate</EavaluateButton>
          </div>
        </div>
      </HeaderElement1>

    </>
  );
}


const Wrapper = styled.section`
  padding-top: 80px;
  width: 100%;
   @media (max-width: 960px) {
    flex-direction: column;
  }
`;
const LeftSide = styled.div`
  width: 50%;
  height: 100%;
  align-items: center;
  @media (max-width: 960px) {
    width: 100%;
    order: 2;
    margin: 50px 0;
    text-align: center;
  }
  @media (max-width: 560px) {
    margin: 80px 0 50px 0;
  }
`;
const RightSide = styled.div`
  width: 50%;
  height: 100%;
  @media (max-width: 960px) {
    width: 100%;
    order: 1;
    margin-top: 30px;
  }
`;
const HeaderP = styled.div`
  max-width: 470px;
  padding: 15px 0 50px 0;
  line-height: 1.5rem;
  @media (max-width: 960px) {
    padding: 15px 0 50px 0;
    text-align: center;
    max-width: 100%;
  }
`;
const BtnWrapper = styled.div`
   max-width: 190px;
   margin-top:20px;
  @media (max-width: 960px) {
    margin: 0 auto;
  }
`;


const NextPrevWrapper = styled.div`
 
 float: left;
 margin-top: 25px
  
`;
const GreyDiv = styled.div`
  width: 30%;
  height: 700px;
  position: absolute;
  top: 0;
  right: 0;
  z-index: 0;
  @media (max-width: 960px) {
    display: none;
  }
`;
const ImageWrapper = styled.div`
  display: flex;
  justify-content: flex-end;
  position: relative;
  z-index: 9;
  @media (max-width: 960px) {
    width: 100%;
    justify-content: center;
  }
`;


const EavaluateButton = styled.button`
 color:#FFF;
 width:100%;
 border-radius: 8px;
background: #2D3291;
box-shadow: 0px -5px 13px 0px rgba(45, 50, 145, 0.12);
   
`;



const HeaderElement1 = styled.div`
 width: 70%;
height: 100px;
background-color: #FFFFFF;

  
  
`;


