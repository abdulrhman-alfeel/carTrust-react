import React from "react";

const Loader = () => {
  return (
    <div id="preloader">
      <div id="status"></div>
    </div>
  );
};

export default Loader;
