import img1 from "../assets/img/headerImage.png";
const images = [
    {
      imgURL: img1,
      imgAlt: "img-1"
    },
    {
      imgURL:
      img1,
      imgAlt: "img-2"
    },
    {
      imgURL:
        img1,
      imgAlt: "img-3"
    },
    {
      imgURL:
        img1,
      imgAlt: "img-4"
    }
  ];
  
  export default images;
  